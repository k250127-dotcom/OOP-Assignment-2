#ifndef ICOMMUNICATABLE_H
#define ICOMMUNICATABLE_H
#include <string>
using namespace std;
class ICommunicatable {
public:
    virtual void sendMessage(const string& content) = 0;
    virtual void receiveMessage(const string& content) = 0;
    virtual ~ICommunicatable() {}
};
#endif