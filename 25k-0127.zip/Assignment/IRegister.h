#ifndef IREGISTRABLE_H
#define IREGISTRABLE_H
#include <string>
using namespace std;
class IRegistrable {
public:
    virtual bool submitApplication() = 0;
    virtual string getRegistrationStatus() const = 0;
    virtual ~IRegistrable() {}
};
#endif