#ifndef ISELLABLE_H
#define ISELLABLE_H
class ISellable {
public:
    virtual double getPrice() const = 0;
    virtual void showDetails() const = 0;
    virtual ~ISellable() {}
};
#endif