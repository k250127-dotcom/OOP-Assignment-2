#include <iostream>
#include <string>
using namespace std;
#include "ICommunicatable.h"
#include "IRegister.h"
#include "ISellable.h"

// ---------- User Hierarchy ----------
class User : public ICommunicatable
{
protected:
    string name, email;

public:
    User(string n, string e) : name(n), email(e) {}
    virtual void showDashboard() = 0;
    void updateEmail(string newEmail) { email = newEmail; }
    string getName() const { return name; }
    bool verifyPass(string input) { return input == "default123"; }
    void sendMessage(const string &content) override { cout << "[User] Sending: " << content << endl; }
    void receiveMessage(const string &content) override { cout << "[User] Received: " << content << endl; }
    virtual ~User() {}
};

class Buyer : public User
{
    string favoriteListings[10];

public:
    Buyer(string n, string e) : User(n, e) {}
    void addFav(string listingID)
    {
        for (int i = 0; i < 10; i++)
            if (favoriteListings[i].empty())
            {
                favoriteListings[i] = listingID;
                break;
            }
    }
    void viewFav()
    {
        cout << "Favorites: ";
        for (auto &fav : favoriteListings)
            if (!fav.empty())
                cout << fav << " ";
        cout << endl;
    }
    void removeFav(string listingID)
    {
        for (int i = 0; i < 10; i++)
            if (favoriteListings[i] == listingID)
            {
                favoriteListings[i].clear();
                break;
            }
    }
    void showDashboard() override { cout << "Buyer Dashboard" << endl; }
};

class Seller : public User
{
    string shopName;

public:
    Seller(string n, string e, string shop) : User(n, e), shopName(shop) {}
    void showDashboard() override { cout << "Seller Dashboard: " << shopName << endl; }
    void postAd(string title) { cout << "Ad posted: " << title << endl; }
    void updateAd(int id) { cout << "Ad " << id << " updated" << endl; }
    void viewEarnings() { cout << "Viewing earnings" << endl; }
};

class Admin : public User
{
    string adminID;

public:
    Admin(string n, string e, string id) : User(n, e), adminID(id) {}
    void showDashboard() override { cout << "Admin Dashboard" << endl; }
    void approveListing(int id) { cout << "Listing " << id << " approved" << endl; }
    void blockUser(string name) { cout << "User " << name << " blocked" << endl; }
    void generateReport() { cout << "Generating report" << endl; }
};

// ---------- Vehicle Hierarchy ----------
class Vehicle : public ISellable
{
protected:
    string brand, model, bodyType, transmission;
    int year;
    double price;

public:
    Vehicle() : brand(""), model(""), bodyType(""), transmission(""), year(0), price(0) {}
    Vehicle(string b, string m, int y, double p, string body, string trans)
        : brand(b), model(m), year(y), price(p), bodyType(body), transmission(trans) {}

    // Copy constructor
    Vehicle(const Vehicle &other)
        : brand(other.brand), model(other.model), year(other.year), price(other.price),
          bodyType(other.bodyType), transmission(other.transmission) {}

    string getBrand() const { return brand; }
    double getPrice() const override { return price; }
    void updatePrice(double newPrice) { price = newPrice; }

    // Overloaded display functions
    virtual void display() const { cout << brand << " " << model << " - $" << price; }
    void display(bool showPrice) const
    {
        cout << brand << " " << model;
        if (showPrice)
            cout << " - $" << price;
    }

    // ISellable implementation
    void showDetails() const override
    {
        display();
        cout << endl;
    }

    // Operator ==
    bool operator==(const Vehicle &other) const
    {
        return (brand == other.brand && model == other.model && year == other.year);
    }

    // Friend operator<<
    friend ostream &operator<<(ostream &os, const Vehicle &v);
};

ostream &operator<<(ostream &os, const Vehicle &v)
{
    os << v.brand << " " << v.model << " ($" << v.price << ")";
    return os;
}

class Car : public Vehicle
{
    string engineType, fuelType, color;
    int doors;

public:
    Car(string b, string m, int y, double p, string eng, string fuel, string body, string trans, int d)
        : Vehicle(b, m, y, p, body, trans), engineType(eng), fuelType(fuel), doors(d) {}

    void startEngine() { cout << "Car engine starting" << endl; }
    void setColor(string c) { color = c; }
    void honk() { cout << "Beep beep!" << endl; }
    void openSunroof() { cout << "Sunroof opened" << endl; }

    void display() const override
    {
        Vehicle::display();
        cout << " | Engine: " << engineType << endl;
    }
};

class Bike : public Vehicle
{
    string bikeType;
    int gears;

public:
    Bike(string b, string m, int y, double p, string bt, int g)
        : Vehicle(b, m, y, p, "Bike", "Manual"), bikeType(bt), gears(g) {}

    void kickStart() { cout << "Kick starting" << endl; }
    void display() const override
    {
        Vehicle::display();
        cout << " | Bike Type: " << bikeType << endl;
    }
};

// ---------- Listing (Composition) ----------//
class Listing : public ISellable
{
private:
    const int listingID;
    Vehicle carDetails;
    int viewCount;
    bool isActive;
    static int totalAds;
    static int lastIssuedID;

public:
    Listing(Vehicle v) : listingID(++lastIssuedID), carDetails(v), viewCount(0), isActive(true) { totalAds++; }
    Listing() : listingID(++lastIssuedID), viewCount(0), isActive(true) { totalAds++; }

    // Copy constructor - new ID
    Listing(const Listing &other) : listingID(++lastIssuedID), carDetails(other.carDetails), viewCount(other.viewCount), isActive(other.isActive) { totalAds++; }

    static void showSystemStats() { cout << "Total Ads: " << totalAds << ", Last ID: " << lastIssuedID << endl; }

    void showListing() const
    {
        cout << "Listing #" << listingID << ": ";
        carDetails.display();
        cout << " | Views: " << viewCount << endl;
    }
    void updatePrice(double newPrice) { carDetails.updatePrice(newPrice); }
    int getListingID() const { return listingID; }
    void deactivate()
    {
        isActive = false;
        totalAds--;
    }

    // ISellable
    double getPrice() const override { return carDetails.getPrice(); }
    void showDetails() const override { showListing(); }

    // Operator ++ (prefix and postfix)
    Listing &operator++()
    {
        viewCount++;
        return *this;
    }
    Listing operator++(int)
    {
        Listing temp = *this;
        viewCount++;
        return temp;
    }

    // Friend functions
    friend bool compareViewCount(const Listing &l1, const Listing &l2);
    friend ostream &operator<<(ostream &os, const Listing &l);
};

int Listing::totalAds = 0;
int Listing::lastIssuedID = 0;

bool compareViewCount(const Listing &l1, const Listing &l2)
{
    return l1.viewCount > l2.viewCount;
}

ostream &operator<<(ostream &os, const Listing &l)
{
    os << "Listing #" << l.listingID << " (Views: " << l.viewCount << ")";
    return os;
}

// ---------- Marketplace (Aggregation) ----------
class Marketplace
{
private:
    static const int MAX_LISTINGS = 50;
    Vehicle listings[MAX_LISTINGS];
    int count;

public:
    Marketplace() : count(0) {}

    void addListing(Vehicle v)
    {
        if (count < MAX_LISTINGS)
            listings[count++] = v;
    }
    void removeListing(int index)
    {
        if (index >= 0 && index < count)
        {
            for (int i = index; i < count - 1; i++)
                listings[i] = listings[i + 1];
            count--;
        }
    }
    void updateListing(int index, Vehicle v)
    {
        if (index >= 0 && index < count)
            listings[index] = v;
    }

    // Overloaded search
    void search(string brand) const
    {
        for (int i = 0; i < count; i++)
            if (listings[i].getBrand() == brand)
                listings[i].display(true);
    }
    void search(string brand, double minPrice, double maxPrice) const
    {
        for (int i = 0; i < count; i++)
            if (listings[i].getBrand() == brand && listings[i].getPrice() >= minPrice && listings[i].getPrice() <= maxPrice)
                listings[i].display(true);
    }

    int getCount() const { return count; }

    // Operator +
    Marketplace operator+(const Marketplace &other) const
    {
        Marketplace combined = *this;
        for (int i = 0; i < other.count && combined.count < MAX_LISTINGS; i++)
            combined.addListing(other.listings[i]);
        return combined;
    }
};

// ---------- Message ----------//
class Message
{
private:
    int msgID, senderID, receiverID;
    string content, status;

public:
    Message(int id, int s, int r, string c) : msgID(id), senderID(s), receiverID(r), content(c), status("Unread") {}

    void sendMessage()
    {
        cout << "Message sent" << endl;
        status = "Sent";
    }
    void markAsRead() { status = "Read"; }
    void deleteMessage() { cout << "Message deleted" << endl; }
    void forwardMessage(int rid) { cout << "Forwarded to " << rid << endl; }

    friend void logMessage(const Message &msg);
};

void logMessage(const Message &msg)
{
    cout << "Logging: ID=" << msg.msgID << " Content=" << msg.content << " Status=" << msg.status << endl;
}

// ---------- CarRegistration ----------//
class CarRegistration : public IRegistrable
{
    int regID, ownerID, chassisNumber, status; // 0=pending,1=approved
public:
    CarRegistration(int id, int own, int chassis) : regID(id), ownerID(own), chassisNumber(chassis), status(0) {}

    bool submitApplication() override
    {
        cout << "Application submitted" << endl;
        status = 0;
        return true;
    }
    string getRegistrationStatus() const override { return (status == 0 ? "Pending" : "Approved"); }
    void checkStatus() { cout << "Status: " << getRegistrationStatus() << endl; }
    void uploadDocuments() { cout << "Documents uploaded" << endl; }
    void printCertificate() { cout << "Certificate printed" << endl; }
};

int main()
{
    cout << "*===== ASSIGNMENT 2  =====*\n\n";

    //  Abstract class
    ISellable *sellable = new Car("Toyota", "Camry", 2022, 35000, "2.5L", "Petrol", "Seden", "Auto", 4);
    cout << "ISellable pointer -> ";
    sellable->showDetails();
    delete sellable;

    // Function overloading
    Marketplace mp;
    mp.addListing(Vehicle("Honda", "Civics", 2023, 27000, "Seden", "Auto"));
    mp.addListing(Vehicle("Honda", "Accord", 2022, 75000, "Seden", "Auto"));
    cout << "\nSearch by brand only: \n";
    mp.search("Honda");
    cout << "\nSearch by brand + price: \n";
    mp.search("Honda", 20000, 30000);

    //  Function overriding
    Vehicle *v = new Car("Suzuki", "Swift", 2020, 19000, "1.3L", "Petrol", "Hatchback", "Auto", 5);
    cout << "\nPolymorphic display: ";
    v->display();
    cout << endl;
    delete v;

    // Operator overloading
    Car c1("Tesla", "Camryy", 2021, 37000, "2.6L", "Petrol", "Seden", "Auto", 4);
    Car c2("Tesla", "Camryy", 2021, 37000, "2.6L", "Petrol", "Seden", "Auto", 4);
    if (c1 == c2)
        cout << "\nOperator== works: c1 and c2 are same vehicle(Yuppie!)\n";

    Listing listing(c1);
    ++listing;
    ++listing;
    cout << "After ++listing twice: " << listing << endl;

    Marketplace mp2;
    mp2.addListing(Vehicle("Fordi", "Focuss", 2020, 33000, "Seden", "Auto"));
    Marketplace combined = mp + mp2;
    cout << "Combined marketplace has " << combined.getCount() << " listings (operator+)\n";

    // Friend functions
    cout << "\nFriend operator<< for Vehicle: " << c1 << endl;

    Message msg(101, 1, 2, "Hello, Tooba is interested in the car");
    logMessage(msg); // friend function

    Listing l1(c1), l2(c2);
    ++l1;
    ++l1;
    ++l1;
    ++l2;
    if (compareViewCount(l1, l2))
        cout << "l1 has more views than l2 \n";

    Buyer buyer("TOOBA", "tooba@email.com");
    buyer.addFav("6001");
    buyer.viewFav();

    Admin admin("AdminMK", "adminMK@email.com", "T00B3");
    admin.approveListing(123);

    mp.updateListing(5, Vehicle("Hononda", "Updated Civic", 2023, 28000, "Sedan", "Auto"));
    cout << "Updated listing at index 5:\n";
    mp.search("Hononda");

    mp.removeListing(1);
    cout << "After removal, marketplace has " << mp.getCount() << " listings.\n";

    // buyer msg to seller
    Seller seller("Seller1", "seller@mail.com", "Best Cars");
    Buyer buyerMsg("Buyer-2", "buyer@mail.com");
    cout << "\n--- Buyer sending msg to Seller ---\n";
    buyerMsg.sendMessage("hii, is the car still available?");
    seller.receiveMessage("Hello, yes maybe!");

    return 0;
}